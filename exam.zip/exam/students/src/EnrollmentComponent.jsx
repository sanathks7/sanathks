import React, { useEffect, useState } from 'react';


const EnrollmentComponent = () => {
    const [students, setStudents] = useState([]); 
    const [courses, setCourses] = useState([]); 
    const [selectedStudent, setSelectedStudent] = useState(''); 
    const [selectedCourse, setSelectedCourse] = useState(''); 
    const [enrollments, setEnrollments] = useState([]); 

    useEffect(() => {
        fetch('/api/students')
            .then(response => response.json())
            .then(data => setStudents(data)); 

        fetch('/api/courses')
            .then(response => response.json())
            .then(data => setCourses(data)); 
    }, []);

    const enrollStudent = (e) => {
        e.preventDefault(); 
        fetch('/api/enrollments', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ studentId: selectedStudent, courseId: selectedCourse }), 
        })
            .then(response => response.json())
            .then(() => {
                fetchEnrollments(selectedStudent); 
            });
    };

    const fetchEnrollments = (studentId) => {
        fetch(`/api/enrollments?studentId=${studentId}`)
            .then(response => response.json())
            .then(data => setEnrollments(data)); 
    };

    return (
        <div>
            <h2>Enroll Student in Course</h2>
            <form onSubmit={enrollStudent}>
                <select value={selectedStudent} onChange={(e) => setSelectedStudent(e.target.value)} required>
                    <option value="">Select Student</option>
                    {students.map(student => (
                        <option key={student.id} value={student.id}>{student.name}</option> 
                    ))}
                </select>
                <select value={selectedCourse} onChange={(e) => setSelectedCourse(e.target.value)} required>
                    <option value="">Select Course</option>
                    {courses.map(course => (
                        <option key={course.id} value={course.id}>{course.name}</option> 
                    ))}
                </select>
                <button type="submit">Enroll</button>
            </form>

            {selectedStudent && (
                <div>
                    <h3>Courses Enrolled for {students.find(s => s.id === selectedStudent)?.name}</h3>
                    <ul>
                        {enrollments.map(enrollment => (
                            <li key={enrollment.id}>{courses.find(c => c.id === enrollment.courseId)?.name}</li> 
                        ))}
                    </ul>
                </div>
            )}
        </div>
    );
};

export default EnrollmentComponent;
