﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using studentEntrolmentsystem.Data;
using studentEntrolmentsystem.Models;

namespace studentEntrolmentsystem.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class coursecontroller : ControllerBase
    {

        private readonly Applicationdbcontext dbContext;

        public coursecontroller(Applicationdbcontext dbContext)
        {
            this.dbContext = dbContext;
        }

        [HttpGet]
        public IActionResult GetAllcourses()
        {
            var course = dbContext.course.ToList();
            return Ok(course);
        }

        [HttpPost]
        public IActionResult Addcourse(course addcourse)
        {
            var course = new course()
            {
                Title = addcourse.Title,

                Description = addcourse.Description


            };
            dbContext.course.Add(course);
            dbContext.SaveChanges();
            return Ok(course);
        }
    }
}
