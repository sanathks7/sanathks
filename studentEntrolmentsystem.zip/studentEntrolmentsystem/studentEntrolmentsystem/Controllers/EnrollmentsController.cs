﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using studentEntrolmentsystem.Data;
using studentEntrolmentsystem.Models;

namespace studentEntrolmentsystem.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EnrollmentsController : ControllerBase
    {
        private readonly Applicationdbcontext dbContext;

        public EnrollmentsController(Applicationdbcontext dbContext)
        {
            this.dbContext = dbContext;
        }

        [HttpGet]
        public IActionResult GetAllcoursedetails()
        {
            var course = dbContext.course.ToList();
            return Ok(course);
        }
        [HttpPost]
        public IActionResult AddEmployee(Enrollment entroll)
        {
            var entrollment = new Enrollment()
            {
                courseid = entroll.courseid


            };
            dbContext.Enrollment.Add(entrollment);
            dbContext.SaveChanges();
            return Ok(entrollment);
        }
    }
}
