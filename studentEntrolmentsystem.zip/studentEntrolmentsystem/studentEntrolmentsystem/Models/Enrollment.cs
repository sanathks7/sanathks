﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace studentEntrolmentsystem.Models
{
    public class Enrollment
    {
        [Key]
        public int Id { get; set; }
        [ForeignKey("studentid")]
        public string studentid { get; set; }
        [ForeignKey("courseid")]
        public string courseid { get; set; }

    }
}
