﻿using Microsoft.EntityFrameworkCore;
using studentEntrolmentsystem.Models;

namespace studentEntrolmentsystem.Data
{
    public class Applicationdbcontext : DbContext
    {
        public Applicationdbcontext(DbContextOptions<Applicationdbcontext> options) : base(options)
        {

        }

        public DbSet<student> student { get; set; }
        public DbSet<course> course { get; set; }

        public DbSet<Enrollment> Enrollment { get; set; }


    }
}
